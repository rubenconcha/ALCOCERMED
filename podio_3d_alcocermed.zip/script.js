
document.querySelectorAll('.player').forEach((card)=>{
  card.addEventListener('mouseenter',()=>{
    card.style.transform='translateY(-10px)';
    card.style.transition='.3s';
  });

  card.addEventListener('mouseleave',()=>{
    card.style.transform='translateY(0)';
  });
});
